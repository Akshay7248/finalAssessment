package project1;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Project1 
{

	public void creatfile() 
	{
		    
		File file = new File("C:\\Users\\User\\Documents\\Desktop\\project\\music.txt"); //initialize File object and passing path as argument  
		boolean result;  
		try   
		{  
		result = file.createNewFile();  //creates a new file  
		if(result)      // test if successfully created a new file  
		{  
		System.out.println("file created "+file.getCanonicalPath()); //returns the path string  
		}  
		else  
		{  
		System.out.println("File already exist at location: "+file.getCanonicalPath());  
		}  
		}   
		catch (IOException e)   
		{  
		e.printStackTrace();    //prints exception if any  
		}         
		}  


		public void listingfiles() 
	{
			
			  // creates a file object
			    File file = new File("C:\\\\Users\\\\User\\\\Documents\\\\Desktop\\\\project\\");

			    // returns an array of all files
			    String[] fileList = file.list();

			    for(String str : fileList) {
			      System.out.println(str);
			    }
			  }
		
		

	public void searchfile() 
	{
		// TODO Auto-generated method stub
		 
		      System.out.println("Enter the path to folder to search for files");
		      Scanner s1 = new Scanner(System.in);
		      String folderPath = s1.next();
		      File folder = new File(folderPath);
		      
		      if (folder.isDirectory()) {
		         File[] listOfFiles = folder.listFiles();
		         if (listOfFiles.length < 1)
		        	 System.out.println("There is no File inside Folder");
		         else System.out.println("List of Files & Folder");
		         for (File file : listOfFiles) {
		            if(!file.isDirectory())
						try {
							System.out.println(
							   file.getCanonicalPath().toString());
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
		         } 
		      } 
		      else System.out .println("There is no Folder @ given path :" + folderPath);
		   }
		
		
	

	public void deletefile() 
	
		// TODO Auto-generated method stub
		 	{     
		try  
		{         
		File f= new File("C:\\Users\\User\\Documents\\Desktop\\project\\music.txt");           //file to be delete  
		if(f.delete())                      //returns Boolean value  
		{  
		System.out.println(f.getName() + " deleted");   //getting and printing the file name  
		}  
		else  
		{  
		System.out.println("failed");  
		}  
		}  
		catch(Exception e)  
		{  
		e.printStackTrace();  
		}  
		}  
		 
		
	

	public void exit() 
	{
		 System.exit(0);
		// TODO Auto-generated method stub
		
	}

}
