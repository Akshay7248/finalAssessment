package project1;
import java.io.File;  
import java.io.IOException;
import java.util.Scanner;
public class Project
{
	public Project(int n) {}

	public static void main(String[] args)
	{
		System.out.println("WELCOME TO LOCKER.IN");
		System.out.println("Developer Details:AKSHAYKUMAR.D");
		 try (Scanner scan = new Scanner(System.in))
		 {
			/* Perform file Operations */        
	        char ch;
	        do{
	            System.out.println("file operations choose any one");
	            System.out.println("1. create file");
	            System.out.println("2. list file");
	            System.out.println("3. search file");
	            System.out.println("4. delete file");
	            System.out.println("5. exit");
	            
	            int choice = scan.nextInt();
	            Project1 a= new Project1();
	            switch (choice)
	            {
	            case 1 :
	            	try {
					a.creatfile();                   
	                break;        
	            	}
	            	 catch(Exception e)
	                {
	                    System.out.println("Error : " +e.getMessage());
	                }
	            case 2 : 
	            	 try {
	                a.listingfiles();
	                break; 
	            	 }
	                catch(Exception e)
	                {
	                    System.out.println("Error : " +e.getMessage());
	                }
	            case 3 : 
	            	try {
	               a.searchfile();
	                break;
	            	}
	            	catch(Exception e)
	                {
	                    System.out.println("Error : " +e.getMessage());
	                }
	            case 4 : 
	            	try {
	                a.deletefile();
	                break;
	            	}
	            	catch(Exception e)
	                {
	                    System.out.println("Error : " +e.getMessage());
	                }
	            case 5 : 
	                a.exit();
	                break;                                                  
	            default : System.out.println("Wrong Entry \n ");
	                break;
	            }           
	            System.out.println("\nDo you want to continue (Type y or n) \n");
	            ch = scan.next().charAt(0);
	 
	        } while (ch == 'Y'|| ch == 'y');
		} 
	}

}
